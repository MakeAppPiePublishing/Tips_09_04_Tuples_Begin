//
//  A Demo for iOS Development Tips Weekly
//  by Steven Lipton (C)2020, All rights reserved
// Check out the video series on LinkedIn learning at https://linkedin-learning.pxf.io/YxZgj
//  For code go to http://bit.ly/AppPieGithub

//:# Introduction to Tuples
import MapKit

//: An example of a Tuple with CLLocationDegrees(i.e. Double) and String
let pizzaPlace = (40.7216,-73.9955,"Lombardi's")
let clCoordinate = CLLocationCoordinate2D(latitude: 40.7216, longitude: -73.9955)

